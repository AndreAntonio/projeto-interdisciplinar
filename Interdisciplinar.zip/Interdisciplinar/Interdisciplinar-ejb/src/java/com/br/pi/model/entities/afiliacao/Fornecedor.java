/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.model.entities.afiliacao;

import com.br.pi.model.entities.contrato.Contrato;
import com.br.pi.model.entities.orcamento.Orcamento;
import com.br.pi.model.entities.avaliacao.Servico;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "FORNECEDOR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Fornecedor.findAll", query = "SELECT f FROM Fornecedor f")
    , @NamedQuery(name = "Fornecedor.findByIdFornecedor", query = "SELECT f FROM Fornecedor f WHERE f.idFornecedor = :idFornecedor")
    , @NamedQuery(name = "Fornecedor.findByNome", query = "SELECT f FROM Fornecedor f WHERE f.nome = :nome")
    , @NamedQuery(name = "Fornecedor.findByEmail", query = "SELECT f FROM Fornecedor f WHERE f.email = :email")
    , @NamedQuery(name = "Fornecedor.findBySenha", query = "SELECT f FROM Fornecedor f WHERE f.senha = :senha")
    , @NamedQuery(name = "Fornecedor.findByTelefone", query = "SELECT f FROM Fornecedor f WHERE f.telefone = :telefone")
    , @NamedQuery(name = "Fornecedor.findByTiposervico", query = "SELECT f FROM Fornecedor f WHERE f.tiposervico = :tiposervico")
    , @NamedQuery(name = "Fornecedor.findByCpf", query = "SELECT f FROM Fornecedor f WHERE f.cpf = :cpf")
    , @NamedQuery(name = "Fornecedor.findByCnpj", query = "SELECT f FROM Fornecedor f WHERE f.cnpj = :cnpj")})
public class Fornecedor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_FORNECEDOR")
    private Long idFornecedor;
    @Size(max = 40)
    @Column(name = "NOME")
    private String nome;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="E-mail inválido")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 60)
    @Column(name = "EMAIL")
    private String email;
    @Size(max = 32)
    @Column(name = "SENHA")
    private String senha;
    @Size(max = 13)
    @Column(name = "TELEFONE")
    private String telefone;
    @Size(max = 50)
    @Column(name = "TIPOSERVICO")
    private String tiposervico;
    @Size(max = 15)
    @Column(name = "CPF")
    private String cpf;
    @Size(max = 20)
    @Column(name = "CNPJ")
    private String cnpj;
    @JoinColumn(name = "ID_FORNECEDOR_CONTRATO", referencedColumnName = "ID_CONTRATO")
    @ManyToOne
    private Contrato idFornecedorContrato;
    @JoinColumn(name = "ID_FORNECEDOR_ORCAMENTO", referencedColumnName = "ID_ORCAMENTO")
    @ManyToOne
    private Orcamento idFornecedorOrcamento;
    @JoinColumn(name = "ID_FORNECEDOR_SERVICO", referencedColumnName = "ID_SERVICO")
    @ManyToOne
    private Servico idFornecedorServico;

    public Fornecedor() {
    }

    public Fornecedor(Long idFornecedor) {
        this.idFornecedor = idFornecedor;
    }

    public Long getIdFornecedor() {
        return idFornecedor;
    }

    public void setIdFornecedor(Long idFornecedor) {
        this.idFornecedor = idFornecedor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getTiposervico() {
        return tiposervico;
    }

    public void setTiposervico(String tiposervico) {
        this.tiposervico = tiposervico;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Contrato getIdFornecedorContrato() {
        return idFornecedorContrato;
    }

    public void setIdFornecedorContrato(Contrato idFornecedorContrato) {
        this.idFornecedorContrato = idFornecedorContrato;
    }

    public Orcamento getIdFornecedorOrcamento() {
        return idFornecedorOrcamento;
    }

    public void setIdFornecedorOrcamento(Orcamento idFornecedorOrcamento) {
        this.idFornecedorOrcamento = idFornecedorOrcamento;
    }

    public Servico getIdFornecedorServico() {
        return idFornecedorServico;
    }

    public void setIdFornecedorServico(Servico idFornecedorServico) {
        this.idFornecedorServico = idFornecedorServico;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idFornecedor != null ? idFornecedor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Fornecedor)) {
            return false;
        }
        Fornecedor other = (Fornecedor) object;
        if ((this.idFornecedor == null && other.idFornecedor != null) || (this.idFornecedor != null && !this.idFornecedor.equals(other.idFornecedor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.br.pi.model.entities.afiliacao.Fornecedor[ idFornecedor=" + idFornecedor + " ]";
    }
    
}
