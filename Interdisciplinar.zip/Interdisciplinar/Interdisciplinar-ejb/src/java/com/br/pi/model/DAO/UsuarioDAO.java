/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.model.DAO;

import com.br.pi.model.entities.afiliacao.Usuario;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/**
 *
 * 
 * @author Pedro
 */
@Stateful
@LocalBean
public class UsuarioDAO implements GenericDAO<Usuario>{
    
    @PersistenceContext(unitName = "Interdisciplinar-ejbPU", type = PersistenceContextType.EXTENDED)
    EntityManager em;

    @Override
    public void create(Usuario e) {
        em.persist(e);
    }

    @Override
    public List<Usuario> read() {
        Query query = em.createNamedQuery("Usuario.findAll",Usuario.class);
        return (List<Usuario>) query.getResultList();
    }

    @Override
    public Usuario readById(long id) {
        return em.find(Usuario.class, id);
    }
      public Usuario readByUsername(String nome) {
         Query query = em.createNamedQuery("Usuario.findByNome").setParameter("nome", nome);
        try{
            Object object = query.getSingleResult();
            return (Usuario)object;
        } catch(NoResultException ex){
            return null;
        }
    }

  
    
    @Override
    public void update(Usuario e) {
        em.merge(e);
    }

    @Override
    public void delete(Usuario e) {
        em.merge(e);
        em.remove(e);
    }
    
}

