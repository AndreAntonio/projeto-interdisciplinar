/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.model.DAO;

import com.br.pi.model.entities.afiliacao.Fornecedor;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/**
 *
 * @author Pedro
 */
@Stateful
@LocalBean
public class FornecedorDAO implements GenericDAO<Fornecedor>{
    
    @PersistenceContext(unitName = "Interdisciplinar-ejbPU", type = PersistenceContextType.EXTENDED)
    EntityManager em;

    @Override
    public void create(Fornecedor e) {
        em.persist(e);
    }

    @Override
    public List<Fornecedor> read() {
        Query query = em.createNamedQuery("Fornecedor.findAll",Fornecedor.class);
        return (List<Fornecedor>) query.getResultList();
    }

    @Override
    public Fornecedor readById(long id) {
        return em.find(Fornecedor.class, id);
    }

    
      public Fornecedor readByNome(String nome) {
         Query query = em.createNamedQuery("Fornecedor.findByNome").setParameter("nome", nome);
        try{
            Object object = query.getSingleResult();
            return (Fornecedor)object;
        } catch(NoResultException ex){
            return null;
        }
    }

    
    @Override
    public void update(Fornecedor e) {
        em.merge(e);
    }

    @Override
    public void delete(Fornecedor e) {
        em.merge(e);
        em.remove(e);
    }
    
}
