/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.model.entities.contrato;

import com.br.pi.model.entities.afiliacao.Fornecedor;
import com.br.pi.model.entities.afiliacao.Usuario;
import com.br.pi.model.entities.pagamento.Pagamento;
import com.br.pi.model.entities.orcamento.Orcamento;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Pedro
 */
@Entity
@Table(name = "CONTRATO")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Contrato.findAll", query = "SELECT c FROM Contrato c")
    , @NamedQuery(name = "Contrato.findByIdContrato", query = "SELECT c FROM Contrato c WHERE c.idContrato = :idContrato")
    , @NamedQuery(name = "Contrato.findByTermodocontrato", query = "SELECT c FROM Contrato c WHERE c.termodocontrato = :termodocontrato")
    , @NamedQuery(name = "Contrato.findByStatus", query = "SELECT c FROM Contrato c WHERE c.status = :status")})
public class Contrato implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_CONTRATO")
    private Long idContrato;
    @Size(max = 1000)
    @Column(name = "TERMODOCONTRATO")
    private String termodocontrato;
    @Size(max = 50)
    @Column(name = "STATUS")
    private String status;
    @OneToMany(mappedBy = "fkContrato")
    private List<Pagamento> pagamentoList;
    @JoinColumn(name = "ID_CONTRATO_ORCAMENTO", referencedColumnName = "ID_ORCAMENTO")
    @ManyToOne
    private Orcamento idContratoOrcamento;
    @JoinColumn(name = "ID_CONTRATO_USUARIO", referencedColumnName = "ID_USUARIO")
    @ManyToOne
    private Usuario idContratoUsuario;
    @OneToMany(mappedBy = "idFornecedorContrato")
    private List<Fornecedor> fornecedorList;

    public Contrato() {
    }

    public Contrato(Long idContrato) {
        this.idContrato = idContrato;
    }

    public Long getIdContrato() {
        return idContrato;
    }

    public void setIdContrato(Long idContrato) {
        this.idContrato = idContrato;
    }

    public String getTermodocontrato() {
        return termodocontrato;
    }

    public void setTermodocontrato(String termodocontrato) {
        this.termodocontrato = termodocontrato;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @XmlTransient
    public List<Pagamento> getPagamentoList() {
        return pagamentoList;
    }

    public void setPagamentoList(List<Pagamento> pagamentoList) {
        this.pagamentoList = pagamentoList;
    }

    public Orcamento getIdContratoOrcamento() {
        return idContratoOrcamento;
    }

    public void setIdContratoOrcamento(Orcamento idContratoOrcamento) {
        this.idContratoOrcamento = idContratoOrcamento;
    }

    public Usuario getIdContratoUsuario() {
        return idContratoUsuario;
    }

    public void setIdContratoUsuario(Usuario idContratoUsuario) {
        this.idContratoUsuario = idContratoUsuario;
    }

    @XmlTransient
    public List<Fornecedor> getFornecedorList() {
        return fornecedorList;
    }

    public void setFornecedorList(List<Fornecedor> fornecedorList) {
        this.fornecedorList = fornecedorList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idContrato != null ? idContrato.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Contrato)) {
            return false;
        }
        Contrato other = (Contrato) object;
        if ((this.idContrato == null && other.idContrato != null) || (this.idContrato != null && !this.idContrato.equals(other.idContrato))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.br.pi.model.entities.afiliacao.Contrato[ idContrato=" + idContrato + " ]";
    }
    
}
