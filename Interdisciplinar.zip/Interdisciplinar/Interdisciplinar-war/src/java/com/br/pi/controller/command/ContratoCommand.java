/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.controller.command;
import com.br.pi.model.DAO.AvaliacaoDAO;
import com.br.pi.model.entities.afiliacao.Usuario;
import com.br.pi.model.entities.avaliacao.Servico;
import com.br.pi.model.entities.contrato.Contrato;
import com.br.pi.model.DAO.ContratoDAO;
import com.br.pi.model.DAO.FornecedorDAO;
import com.br.pi.model.DAO.OrcamentoDAO;
import com.br.pi.model.DAO.PagamentoDAO;
import com.br.pi.model.DAO.ServicoDAO;
import com.br.pi.model.DAO.UsuarioDAO;
import com.br.pi.model.entities.afiliacao.Fornecedor;
import com.br.pi.model.entities.avaliacao.Avaliacao;
import com.br.pi.model.entities.orcamento.Orcamento;
import static java.lang.System.out;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Pedro
 */
public class ContratoCommand implements Command{

    UsuarioDAO usuarioDAO = lookupUsuarioDAOBean();

    ServicoDAO servicoDAO = lookupServicoDAOBean();

    PagamentoDAO pagamentoDAO = lookupPagamentoDAOBean();

    OrcamentoDAO orcamentoDAO = lookupOrcamentoDAOBean();

    FornecedorDAO fornecedorDAO = lookupFornecedorDAOBean();

    ContratoDAO contratoDAO = lookupContratoDAOBean();

    AvaliacaoDAO avaliacaoDAO = lookupAvaliacaoDAOBean();



   

  

    

    
   
    
    
    private String responsePage = "Contrato.jsp";
    private HttpServletRequest request;
    private HttpServletResponse response;
    private String username;
    private String password;
    private long id  = 1; // trocar o id quando for fazer um novo contrato
                 Contrato c = new Contrato ();

    
    
    @Override
    public void init(HttpServletRequest request, HttpServletResponse response) {
        this.request = request;
        this.response = response;
    
    }

    @Override
    public void execute() {
         String action = request.getParameter("command").split("\\.")[1];
         switch(action){
             case "gerar":
                 // Criando dados fictícios

                 Servico s = new Servico();
                 Usuario u2 = new Usuario();
                 Fornecedor f = new Fornecedor();
                
                 //Cliente        
                 /*
                        u2.setNome("jovem");
                        u2.setSenha("123");
                        u2.setTipo("1");
                        u2.setTelefone("1926-4723");
                        u2.setEmail("jovem@hotmail.com");
                        if (u2.getTipo() == "1") {
                        u2.setCpf("153.416.789-12");
                        usuarioDAO.create(u2);
                        } else{
                            u2.setCnpj("123.436.759-12");
                        
                        usuarioDAO.create(u2);
                        }
                   */     
                           //Fornecedor
                        f.setNome("domingos");
                        f.setEmail("domingos@gmail.com");
                        f.setTelefone("8121-0111");
                        f.setTiposervico("pedreiro");
                        f.setCpf("122.532.134-83");
                        f.setSenha("cri");
                        fornecedorDAO.create(f);
                        
                 //Servico
                        double val = 120;
                        s.setDescricao("Neste trabalho será realizado o serviço de pedreiro.");
                        s.setValor(val);
                        s.setStatus(Boolean.TRUE);
                      Usuario pf =  usuarioDAO.readByUsername("jovem");
                        s.setFkUsuario(pf);
                        servicoDAO.create(s);
                      
                                     
                 
              
    responsePage = "index.jsp";
                 break;
                 
                 case "logoutF":
                     
                     long ForneId = Long.parseLong(request.getParameter("id_forn"));
                     Fornecedor lele = fornecedorDAO.readById(ForneId);
                     request.getSession().invalidate();
                responsePage = "index.jsp";
                     
                 break;
             case "logout":
                long aux4 = Long.parseLong(request.getParameter("id_usuario")); 
                Usuario lala = usuarioDAO.readById(aux4);
                request.getSession().invalidate();
                 
                responsePage = "index.jsp";
                 break;
                 
             case "login":
                 
                username = request.getParameter("nome");
                password = request.getParameter("senha");
                Fornecedor fAux = fornecedorDAO.readByNome(username);
                System.out.print(fAux);
                Usuario tempAux = usuarioDAO.readByUsername(username);
                    //SE EXISTE, CHECA SE A SENHA É IGUAL
                if (tempAux != null){ 
                if (password.equals(tempAux.getSenha())) {
                
                List<Servico> servicos = servicoDAO.read();
                 for (Servico servico : servicos) {
                    if( tempAux.equals(servico.getFkUsuario())){
                tempAux.setServicoList(servicos);                        
                    }
                 }
                        
                List<Contrato> contratos = contratoDAO.read();
                 for (Contrato contrato : contratos) {
                    if( tempAux.equals(contrato.getIdContratoUsuario())){
                tempAux.setContratoList(contratos);
                
                    }
                 }
                
                 request.getSession().setAttribute("user", tempAux);
                request.getSession().setAttribute("servicos", servicos);
                request.getSession().setAttribute("contratos", contratos);
                
                }}
                else  if(password.equals(fAux.getSenha())){
                  List<Contrato> contratos = contratoDAO.read();
                 for (Contrato contrato : contratos) {
                   if(fAux.getIdFornecedorContrato().equals(contrato)){
                       request.getSession().setAttribute("contaux", contrato);
                   }
                 }

                 request.getSession().setAttribute("forn", fAux);
                    
                }
                
            responsePage = "home.jsp";
                 
                 break;
                 
             case "contratoF":
                 Usuario uAux = new Usuario();
                 Contrato cAux = new Contrato();
                 Servico sAux = new Servico();
                 long fornId = Long.parseLong(request.getParameter("id_fornecedor"));
                 long servId = Long.parseLong(request.getParameter("idServicoF"));
                 // Pegando fornecedor
                 Fornecedor fAux2 = fornecedorDAO.readById(fornId);
                 String nome_cli = request.getParameter("nomeCli");
                 String statusC = request.getParameter("statusC");
                 uAux = usuarioDAO.readByUsername(nome_cli);
                 //Colocando o usuario no contrato
                 
                 cAux.setStatus(statusC);
                 cAux.setTermodocontrato("dsahudsnklcsansidoaf");
                 //Setando o serviço no fornecedor
                 sAux = servicoDAO.readById(servId);
                 fAux2.setIdFornecedorServico(sAux);
                 fAux2.setIdFornecedorContrato(cAux);
                 contratoDAO.create(cAux);
                 fornecedorDAO.update(fAux2);
                 
                 request.getSession().setAttribute("contratoaux", cAux);
                
                  responsePage = "home.jsp";
                      
                 break;
                 
             case "contrato":
                 long contratoID = 0;
                  Fornecedor fAuxiliar = new Fornecedor();
                long aux = Long.parseLong(request.getParameter("id_usuario")); 
                 tempAux = usuarioDAO.readById(aux);
                 long aux1 = Long.parseLong(request.getParameter("id_servico"));
                  Servico tempServico = servicoDAO.readById(aux1);
                //Pegar fornecedor
                  List<Fornecedor> fornecedores = fornecedorDAO.read();
                 for (Fornecedor fornecedor : fornecedores) {
                    if(fornecedor.getIdFornecedorServico().equals(tempServico)){
                        contratoID = fornecedor.getIdFornecedorContrato().getIdContrato();
                    }
                 }
               c =  contratoDAO.readById(contratoID);
                  c.setIdContratoUsuario(tempAux);
                  contratoDAO.update(c);
                  
                 request.getSession().setAttribute("contratoaux", c);
                
            responsePage = "contratinho.jsp";
                      
                 break;
                 
             case "orcamento":
                 Fornecedor bla = new Fornecedor();
                 Orcamento oAux = new Orcamento();
                 Servico sAux2 = new Servico();
                  long aux3 = Long.parseLong(request.getParameter("contaux"));
                 long aux7 = Long.parseLong(request.getParameter("id_forn"));
               bla =  fornecedorDAO.readById(aux7);
                c =  contratoDAO.readById(aux3);
              sAux2 = servicoDAO.readById(bla.getIdFornecedorServico().getIdServico());
                double vTotal = Double.parseDouble(request.getParameter("vTotal"));
                String status = request.getParameter("status");
                String tTotal = request.getParameter("tTotal");
                oAux.setStatus(status);
                oAux.setTempotot(tTotal);
                oAux.setValortot(vTotal);
                orcamentoDAO.create(oAux);
                bla.setIdFornecedorOrcamento(oAux);
                sAux2.setIdServicoOrcamento(oAux);
                c.setIdContratoOrcamento(oAux);
                contratoDAO.update(c);
                fornecedorDAO.update(bla);
                servicoDAO.update(sAux2);
                
                 responsePage = "home.jsp";
                 break;
                 
                      
             case "orcamentoAtu":
                 Fornecedor bla1 = new Fornecedor();
                 Orcamento oAux1 = new Orcamento();
                 Servico sAux21 = new Servico();
                 Contrato c1 = new Contrato(); 
                 long aux31 = Long.parseLong(request.getParameter("contaux"));
                 long aux71 = Long.parseLong(request.getParameter("id_forn"));
               bla1 =  fornecedorDAO.readById(aux71);
                c1 =  contratoDAO.readById(aux31);
              sAux2 = servicoDAO.readById(bla1.getIdFornecedorServico().getIdServico());
              oAux1 = orcamentoDAO.readById(bla1.getIdFornecedorOrcamento().getIdOrcamento());
                double vTotal1 = Double.parseDouble(request.getParameter("vTotal"));
                String status1 = request.getParameter("status");
                String tTotal1 = request.getParameter("tTotal");
                oAux1.setStatus(status1);
                oAux1.setTempotot(tTotal1);
                oAux1.setValortot(vTotal1);
                orcamentoDAO.update(oAux1);
                bla1.setIdFornecedorOrcamento(oAux1);
                sAux21.setIdServicoOrcamento(oAux1);
                c1.setIdContratoOrcamento(oAux1);
                contratoDAO.update(c1);
                fornecedorDAO.update(bla1);
                servicoDAO.update(sAux21);
                
                 responsePage = "home.jsp";
                 break;
                 
             case "visualizar":
                 aux = Long.parseLong(request.getParameter("id_usuario")); 
                 Usuario opa;
                opa = usuarioDAO.readById(aux);
                List<Contrato> contratos1 = contratoDAO.read();
                 for (Contrato contrato : contratos1) {
                    if( opa.equals(contrato.getIdContratoUsuario())){
                        Contrato contra = contrato;
                        request.getSession().setAttribute("contrato", contra);
                       
                        
                   
                    }
                 }
                 responsePage = "Vizualizacao.jsp";
                 
                 break;
             case "voltar":
                 responsePage = "home.jsp";
                         break;
             case "excluir":
                 aux = Long.parseLong(request.getParameter("id_usuario"));
                opa = usuarioDAO.readById(aux);
                List<Contrato> contratos2 = contratoDAO.read();
                 for (Contrato contrato : contratos2) {
                    if( opa.equals(contrato.getIdContratoUsuario())){
                        contratoDAO.delete(contrato);
                        
                   
                    }
                 }
                 responsePage = "index.jsp";
                 break;
         }
         
    }

    @Override
    public String getResponsePage() {
       return responsePage;
     }

    private AvaliacaoDAO lookupAvaliacaoDAOBean() {
        try {
            Context c = new InitialContext();
            return (AvaliacaoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/AvaliacaoDAO!com.br.pi.model.DAO.AvaliacaoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ContratoDAO lookupContratoDAOBean() {
        try {
            Context c = new InitialContext();
            return (ContratoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/ContratoDAO!com.br.pi.model.DAO.ContratoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private FornecedorDAO lookupFornecedorDAOBean() {
        try {
            Context c = new InitialContext();
            return (FornecedorDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/FornecedorDAO!com.br.pi.model.DAO.FornecedorDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private OrcamentoDAO lookupOrcamentoDAOBean() {
        try {
            Context c = new InitialContext();
            return (OrcamentoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/OrcamentoDAO!com.br.pi.model.DAO.OrcamentoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private PagamentoDAO lookupPagamentoDAOBean() {
        try {
            Context c = new InitialContext();
            return (PagamentoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/PagamentoDAO!com.br.pi.model.DAO.PagamentoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private ServicoDAO lookupServicoDAOBean() {
        try {
            Context c = new InitialContext();
            return (ServicoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/ServicoDAO!com.br.pi.model.DAO.ServicoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsuarioDAO lookupUsuarioDAOBean() {
        try {
            Context c = new InitialContext();
            return (UsuarioDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/UsuarioDAO!com.br.pi.model.DAO.UsuarioDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

  
    

}
