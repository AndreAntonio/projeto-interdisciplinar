/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.controller.command;

import com.br.pi.model.DAO.ContratoDAO;
import com.br.pi.model.DAO.FornecedorDAO;
import com.br.pi.model.DAO.PagamentoDAO;
import com.br.pi.model.DAO.UsuarioDAO;
import com.br.pi.model.entities.afiliacao.Usuario;
import com.br.pi.model.entities.contrato.Contrato;
import com.br.pi.model.entities.pagamento.Pagamento;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Pedro
 */
public class PagamentoCommand implements Command{

    UsuarioDAO usuarioDAO = lookupUsuarioDAOBean();

    PagamentoDAO pagamentoDAO = lookupPagamentoDAOBean();

    FornecedorDAO fornecedorDAO = lookupFornecedorDAOBean();

    ContratoDAO contratoDAO = lookupContratoDAOBean();

  

    
  

    private String responsePage = "Contrato.jsp";
    private HttpServletRequest request;
    private HttpServletResponse response;
    
    @Override
    public void init(HttpServletRequest request, HttpServletResponse response) {
    this.request = request;
        this.response = response;
    }

    @Override
    public void execute() {
         String action = request.getParameter("command").split("\\.")[1];
         switch(action){
             case "pagar":
                         int tipo = Integer.parseInt(request.getParameter("tipo"));
                        int id = Integer.parseInt(request.getParameter("id_usuario"));
                        Usuario tempUsuario = usuarioDAO.readById(id);
                                       Pagamento aux = new Pagamento();
                                    List<Contrato> contratos = contratoDAO.read();
                                    for (Contrato contrato : contratos) {
                                     if( tempUsuario.getIdUsuario().equals(contrato.getIdContratoUsuario().getIdUsuario())){
                                      double precoaux = contrato.getIdContratoOrcamento().getValortot();
                                      aux.setPreco(precoaux);
                                      aux.setFkContrato(contrato);
                                       aux.setTipo(tipo);
                                       aux.setFkCliente(tempUsuario);
                    }
    
                                        
                 }
                                       
                                       pagamentoDAO.create(aux);
                                       request.getSession().setAttribute("pagamento", aux);
                                    responsePage = "pagamento.jsp";
             break;
             case "pago":
               long id_user =  Long.parseLong(request.getParameter("id_usuario"));
               long id_pag =  Long.parseLong(request.getParameter("id_pagamento"));
               Pagamento pgto = new Pagamento();
             pgto =  pagamentoDAO.readById(id_pag);
               
                    request.getSession().setAttribute("valor_pago", pgto);
                Contrato caux = new Contrato();
                caux = contratoDAO.readById(pgto.getFkContrato().getIdContrato());
                //atualizar status
                pgto.setStatus("Finalizado");
                caux.setStatus("Finalizado");
                pagamentoDAO.update(pgto);
                contratoDAO.delete(caux);
                                    responsePage = "pgto.jsp";
                 break;
         }
    }

    @Override
    public String getResponsePage() {
       return responsePage;
    }

    private ContratoDAO lookupContratoDAOBean() {
        try {
            Context c = new InitialContext();
            return (ContratoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/ContratoDAO!com.br.pi.model.DAO.ContratoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private FornecedorDAO lookupFornecedorDAOBean() {
        try {
            Context c = new InitialContext();
            return (FornecedorDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/FornecedorDAO!com.br.pi.model.DAO.FornecedorDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private PagamentoDAO lookupPagamentoDAOBean() {
        try {
            Context c = new InitialContext();
            return (PagamentoDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/PagamentoDAO!com.br.pi.model.DAO.PagamentoDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    private UsuarioDAO lookupUsuarioDAOBean() {
        try {
            Context c = new InitialContext();
            return (UsuarioDAO) c.lookup("java:global/Interdisciplinar/Interdisciplinar-ejb/UsuarioDAO!com.br.pi.model.DAO.UsuarioDAO");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }

    
    
    
   
   
   
   

}
