/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.controller.command;

import com.br.pi.dao.GenericDAO;
import com.br.pi.dao.UserPerfilDAO;
import com.br.pi.entities.Userinf;
import com.br.pi.entities.Userperfil;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 31427782
 */
public class AfiliarCommand implements Command{
    
    private HttpServletRequest request;
    private HttpServletResponse response;
    private String responsePage;
    
    private String nome;
    private String email;
    private String telefone;
    
    @EJB
    GenericDAO generic;

    @Override
    public void init(HttpServletRequest request, HttpServletResponse response) {
        this.request = request;
        this.response = response;
    }

    @Override
    public void execute() {
        String flag = request.getParameter("command").split("\\.")[1];
        switch(flag){
            case "logar":                
                //responsePage = "/Controller";
                String login = request.getParameter("loginField");
                String senha = request.getParameter("senhaField");
                if("admin".equals(login) && "123".equals(senha)){
                    request.getSession().setAttribute("nome", "Admin");
                    request.getSession().setAttribute("email", "admin@admin");
                    request.getSession().setAttribute("telefone", "1234-5678");
                    request.getSession().setAttribute("cpf", "123.456.789-10");
                    request.getSession().setAttribute("cnpj", "12.345.678/0009-12");
                    responsePage = "home.jsp";
                }             
                
                /*List<Userperfil> listaUser = generic.read();
                
                for (Userperfil up  : listaUser) {
                    //Login pelo Email do caboclo
                    if(login.equals(up.getEmail()) && senha.equals(up.getSenha())){
                        //Setando o IdUsuario na Session
                        request.getSession().setAttribute("idUsuario", up.getIdUsuario());
                        request.getSession().setAttribute("login", up.getEmail());
                        responsePage = "home.jsp";
                    }
                    //Login pelo Nome do caboclo
                    else if(login.equals(up.getNome()) && senha.equals(up.getSenha())){
                        //Setando o IdUsuario na Session
                        request.getSession().setAttribute("idUsuario", up.getIdUsuario());
                        request.getSession().setAttribute("login", up.getNome());
                        responsePage = "home.jsp";
                    }                                    
                    else                        
                        responsePage = "index.jsp";
                }*/
                else{
                    request.getSession().setAttribute("msgErro", "Login e/ou Senha inválido(s)");
                    responsePage = "erro.jsp";
                }
                break;
            case "cadastro":
                //Se algum dos campos vier vazio, é redirecionado pra página de Erro
                if(
                    request.getParameter("nome").length() == 0 ||
                    request.getParameter("senha").length() == 0||
                    request.getParameter("email").length() == 0||
                    request.getParameter("telefone").length()==0
                  )
                {
                    request.getSession().setAttribute("msgErro", "Certifique-se de não deixar nenhum campo em branco!");
                    responsePage = "erro.jsp";
                }
                //Se estiverem preenchidos, prossegue com o cadastro
                else
                {
                    
                    //Setando o nome na Session que vem pelo form
                    request.getSession().setAttribute("nome", request.getParameter("nome"));
                    //nome = request.getParameter("nome");
                    //Setando a senha na Session que vem pelo form
                    //request.getSession().setAttribute("senha", request.getParameter("senha"));                    
                    //Setando o email na Session que vem pelo form
                    request.getSession().setAttribute("email", request.getParameter("email"));
                    //email = request.getParameter("email");
                    //Setando o telefone na Session que vem pelo form 
                    request.getSession().setAttribute("telefone", request.getParameter("telefone")); 
                    //telefone = request.getParameter("telefone");
                    
                    responsePage = "cadastro.jsp";                    
                }
                break;
                
            case "finalizarCadastro":
                
                if(!validaCPF(request.getParameter("cpf"))){
                    request.getSession().setAttribute("msgErro", "CPF Inválido!");
                    responsePage = "erro.jsp";
                    break;
                }             
                if(!validaCNPJ(request.getParameter("cnpj"))){
                    request.getSession().setAttribute("msgErro", "CNPJ Invalido");
                    responsePage = "erro.jsp";
                    break;
                }
                                
                    
                /*if("false".equals(request.getParameter("fornecedor"))){
                    //Não é fornecedor caso "false"
                    //ui.setFornecedor(Boolean.FALSE);
                    request.getSession().setAttribute("fornecedor", "false");
                }
                else
                    //Caso contrário, "true"
                    //ui.setFornecedor(Boolean.TRUE);
                    request.getSession().setAttribute("fonecedor", "true");
                
                if("false".equals(request.getParameter("cliente"))){
                    //Não é cliente caso "false"
                    //ui.setCliente(Boolean.FALSE);
                    request.getSession().setAttribute("cliente", "false");
                }
                else{
                    //Caso contrário, "true"
                    //ui.setCliente(Boolean.TRUE);
                    request.getSession().setAttribute("cliente", "true");
                }*/
                //Setando os valores na Session que vieram na primeira tela
                //request.getSession().setAttribute("nome", nome);
                //request.getSession().setAttribute("email", email);
                //request.getSession().setAttribute("telefone", telefone);
                request.getSession().setAttribute("nome", request.getParameter("nome"));
                request.getSession().setAttribute("email", request.getParameter("email"));
                request.getSession().setAttribute("telefone", request.getParameter("telefone"));
                request.getSession().setAttribute("cpf", request.getParameter("cpf"));
                request.getSession().setAttribute("cnpj", request.getParameter("cnpj"));
                
                
                responsePage = "home.jsp";
                /****************************************************/
                /**
                 * ---Inserção no BD---
                 * Inserindo o USerPerfil
                 * 
                 * 
                */
                    /*Userperfil insere = new Userperfil();
                    insere.setNome(request.getParameter("nome"));
                    insere.setSenha(request.getParameter("senha"));
                    insere.setEmail(request.getParameter("email"));
                    insere.setTelefone(request.getParameter("telefone"));
                    generic.insert(insere);
                    
                    //Resgatando o ID do usuário
                    int idUser = generic.findId(insere);
                    
                    //Setando o ID do usuário na session
                    request.getSession().setAttribute("iduser", idUser);
                    
                    //Setando o UserInf
                    ui.setCpf(request.getParameter("cpf"));
                    ui.setCnpj(request.getParameter("cnpj"));
                    
                    ui.setUserperfil(insere);
                    
                    //Serialziando o UserInforamtion
                    generic.insert(ui);*/
                    
                /****************************************************/
                break;                                
                
            case "cancelarCadastro":
                responsePage = "index.jsp";
                break;
                
            case "gerenciarPerfil":
                responsePage = "gerenciar.jsp";
            break;            
        }       
    }

    @Override
    public String getResponsePage() {
        return responsePage;
    }
    
    public boolean validaCPF(String cpf){
        //Se o CPF tem menos do que 11, já não é válido
        //Exemplo CPF: 12345678910 (11 posições)
        //Exemplo CPF: 123456789-10 (12 posições)
        //Exemplo CPF: 123.456.789-10 (14 posições)
        if(cpf.length() < 11 && cpf.length() > 0)
            return false;
        
        String valida[] = cpf.split(".");
        String alfa[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O",
                         "P","Q","R","S","T","U","V","W","X","Y","Z","Ç"};
        
        //Passando os 'splits' pra uma String pra ver se tem letra
        for (int i = 0; i < valida.length; i++) {
            String string = valida[i].toUpperCase();
            //Conferindo com o Array do alfabeto
            for (int j = 0; j < alfa.length; j++) {
                if(string.matches(alfa[i]))
                    return false;
            }
        }
        return true;
    }
    /**
     *  Método para validar o CNPJ
     *  verificando se não foi digitado nenhuma letra
     *  retorna TRUE caso o CNPJ seja válido
     */
    public boolean validaCNPJ(String cnpj){
        //Se o CNPJ tem menos do que 12, já não é válido
        //Exemplo CNPJ: 12345678000910 (14 posições)
        //Exemplo CPF: 12345678/0009-10 (16 posições)
        //Exemplo CPF: 12.345.678/0009-10 (18 posições)
        if(cnpj.length() < 14 && cnpj.length() > 0)
            return false;
        
        String valida[] = cnpj.split(".");
        String alfa[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O",
                         "P","Q","R","S","T","U","V","W","X","Y","Z","Ç"};
        
        //Passando os 'splits' pra uma String pra ver se tem letra
        for (int i = 0; i < valida.length; i++) {
            String string = valida[i].toUpperCase();
            //Conferindo com o Array do alfabeto
            for (int j = 0; j < alfa.length; j++) {
                if(string.matches(alfa[i]))
                    return false;
            }
        }
        return true;
    }
    
}