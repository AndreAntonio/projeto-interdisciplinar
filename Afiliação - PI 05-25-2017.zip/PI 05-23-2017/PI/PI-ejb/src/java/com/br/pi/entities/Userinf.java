/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Giovanni
 */
@Entity
@Table(name = "userinf")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Userinf.findAll", query = "SELECT u FROM Userinf u")
    , @NamedQuery(name = "Userinf.findByIduserinf", query = "SELECT u FROM Userinf u WHERE u.userinfPK.iduserinf = :iduserinf")
    , @NamedQuery(name = "Userinf.findByIdUsuario", query = "SELECT u FROM Userinf u WHERE u.userinfPK.idUsuario = :idUsuario")
    , @NamedQuery(name = "Userinf.findByCpf", query = "SELECT u FROM Userinf u WHERE u.cpf = :cpf")
    , @NamedQuery(name = "Userinf.findByCnpj", query = "SELECT u FROM Userinf u WHERE u.cnpj = :cnpj")
    , @NamedQuery(name = "Userinf.findByFornecedor", query = "SELECT u FROM Userinf u WHERE u.fornecedor = :fornecedor")
    , @NamedQuery(name = "Userinf.findByCliente", query = "SELECT u FROM Userinf u WHERE u.cliente = :cliente")})
public class Userinf implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UserinfPK userinfPK;
    @Size(max = 15)
    @Column(name = "CPF")
    private String cpf;
    @Size(max = 20)
    @Column(name = "CNPJ")
    private String cnpj;
    @Column(name = "FORNECEDOR")
    private Boolean fornecedor;
    @Column(name = "CLIENTE")
    private Boolean cliente;
    @JoinColumn(name = "idUsuario", referencedColumnName = "idUsuario", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Userperfil userperfil;

    public Userinf() {
    }

    public Userinf(UserinfPK userinfPK) {
        this.userinfPK = userinfPK;
    }

    public Userinf(int iduserinf, int idUsuario) {
        this.userinfPK = new UserinfPK(iduserinf, idUsuario);
    }

    public UserinfPK getUserinfPK() {
        return userinfPK;
    }

    public void setUserinfPK(UserinfPK userinfPK) {
        this.userinfPK = userinfPK;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Boolean getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Boolean fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Boolean getCliente() {
        return cliente;
    }

    public void setCliente(Boolean cliente) {
        this.cliente = cliente;
    }

    public Userperfil getUserperfil() {
        return userperfil;
    }

    public void setUserperfil(Userperfil userperfil) {
        this.userperfil = userperfil;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userinfPK != null ? userinfPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userinf)) {
            return false;
        }
        Userinf other = (Userinf) object;
        if ((this.userinfPK == null && other.userinfPK != null) || (this.userinfPK != null && !this.userinfPK.equals(other.userinfPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.br.pi.entities.Userinf[ userinfPK=" + userinfPK + " ]";
    }
    
     /**
     *  Método para validar o CPF
     *  verificando se não foi digitado nenhuma letra
     *  retorna um TRUE caso o CPF seja válido
     */
    public boolean validaCPF(String cpf){
        //Se o CPF tem menos do que 11, já não é válido
        //Exemplo CPF: 12345678910 (11 posições)
        //Exemplo CPF: 123456789-10 (12 posições)
        //Exemplo CPF: 123.456.789-10 (14 posições)
        if(cpf.length() < 11 && cpf.length() > 0)
            return false;
        
        String valida[] = cpf.split(".");
        String alfa[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O",
                         "P","Q","R","S","T","U","V","W","X","Y","Z","Ç"};
        
        //Passando os 'splits' pra uma String pra ver se tem letra
        for (int i = 0; i < valida.length; i++) {
            String string = valida[i].toUpperCase();
            //Conferindo com o Array do alfabeto
            for (int j = 0; j < alfa.length; j++) {
                if(string.matches(alfa[i]))
                    return false;
            }
        }
        return true;
    }
    /**
     *  Método para validar o CNPJ
     *  verificando se não foi digitado nenhuma letra
     *  retorna TRUE caso o CNPJ seja válido
     */
    public boolean validaCNPJ(String cnpj){
        //Se o CNPJ tem menos do que 12, já não é válido
        //Exemplo CNPJ: 12345678000910 (14 posições)
        //Exemplo CPF: 12345678/0009-10 (16 posições)
        //Exemplo CPF: 12.345.678/0009-10 (18 posições)
        if(cnpj.length() < 14 && cnpj.length() > 0)
            return false;
        
        String valida[] = cnpj.split(".");
        String alfa[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O",
                         "P","Q","R","S","T","U","V","W","X","Y","Z","Ç"};
        
        //Passando os 'splits' pra uma String pra ver se tem letra
        for (int i = 0; i < valida.length; i++) {
            String string = valida[i].toUpperCase();
            //Conferindo com o Array do alfabeto
            for (int j = 0; j < alfa.length; j++) {
                if(string.matches(alfa[i]))
                    return false;
            }
        }
        return true;
    }
    
}
