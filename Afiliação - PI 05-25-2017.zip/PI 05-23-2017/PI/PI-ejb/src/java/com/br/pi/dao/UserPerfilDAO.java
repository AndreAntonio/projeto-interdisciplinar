/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.dao;

import com.br.pi.entities.Userperfil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Giovanni
 */
public class UserPerfilDAO implements GenericDAO<Userperfil> {

    public UserPerfilDAO() {
    }
    
    
    //EntityManagerFactory emf = Persistence.createEntityManagerFactory("PI-ejbPU");
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PI-warPU");
    @PersistenceContext
    EntityManager em = emf.createEntityManager();
    

    @Override
    public void insert(Userperfil up) { 
        em.getTransaction().begin();
        em.persist(up);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public List<Userperfil> read(){        
        em.getTransaction().begin();         
        Query q = em.createNamedQuery("Userperfil.findAll");
        List<Userperfil> list = q.getResultList();
        em.getTransaction().commit();
        em.close();
        return list;        
        
    }

    @Override
    public void update(Userperfil up) {
        em.getTransaction().begin();
        Userperfil atualizar = em.find(Userperfil.class, up.getIdUsuario());
        atualizar.setNome(up.getNome());
        atualizar.setSenha(up.getSenha());
        atualizar.setEmail(up.getEmail());
        atualizar.setTelefone(up.getTelefone());
        em.persist(atualizar);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void delete(Userperfil up) {
        em.getTransaction().begin();
        Userperfil excluir = em.find(Userperfil.class, up.getIdUsuario());
        em.detach(excluir);
        em.getTransaction().commit();
        em.close();
    }
    
    /**
     *  Método pra achar o ID do usuário sempre que precisar 
     */
    public int findId(Userperfil up){
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT idUsuario FROM userperfil  WHERE email = emailVar").setParameter("emailVar", up.getEmail());
        int id = (Integer)query.getSingleResult();
        em.getTransaction().commit();
        em.close();
        return id; 
    }
    
}
