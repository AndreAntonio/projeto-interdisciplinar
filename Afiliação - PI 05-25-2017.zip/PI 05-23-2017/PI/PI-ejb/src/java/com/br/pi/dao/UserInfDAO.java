/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.pi.dao;

import com.br.pi.entities.Userinf;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Giovanni
 */
public class UserInfDAO implements GenericDAO<Userinf>{
    
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PI-warPU");
    @PersistenceContext
    EntityManager em = emf.createEntityManager();

    @Override
    public void insert(Userinf ui) {
        em.getTransaction().begin();
        em.persist(ui);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public List<Userinf> read() {
        em.getTransaction().begin();         
        Query q = em.createNamedQuery("Userinf.findAll");
        List<Userinf> list = q.getResultList();
        em.getTransaction().commit();
        em.close();
        return list; 
    }

    @Override
    public void update(Userinf ui) {
        em.getTransaction().begin();
        Userinf atualizar = em.find(Userinf.class, ui.getUserperfil().getIdUsuario());
        atualizar.setCpf(ui.getCpf());
        atualizar.setCnpj(ui.getCnpj());
        atualizar.setFornecedor(ui.getFornecedor());
        atualizar.setCliente(ui.getCliente());
        em.persist(atualizar);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public void delete(Userinf ui) {
        em.getTransaction().begin();
        Userinf excluir = em.find(Userinf.class, ui.getUserperfil().getIdUsuario());
        em.detach(excluir);
        em.getTransaction().commit();
        em.close();
    }
    
    /**
     * Método pra achar o Id do UserInf 
     */
    @Override
    public int findId(Userinf ui) {
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT iduserinf FROM userinf  WHERE iduser = iduserVar").setParameter("iduserVar", ui.getUserperfil().getIdUsuario());
        int id = (Integer)query.getSingleResult();
        em.getTransaction().commit();
        em.close();
        return id; 
    }

   
}
